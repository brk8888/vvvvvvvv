# Digitiva CRM (Mini)

Vite + React + Tailwind ile paketlenmiş, **Excel içe aktarma → fırsat kartları → aksiyon planlama → satış ekleme** akışı.
Veriler LocalStorage'ta saklanır; backend gerektirmez.

## Kurulum
```bash
npm i
npm run dev
```

## Derleme
```bash
npm run build
npm run preview
```

## GitHub'a yükleme (yeni repo)
```bash
git init
git add .
git commit -m "Digitiva CRM: initial commit"
# GitHub'da boş bir repo oluştur (ör. digitiva-crm) ve URL'yi aşağıda kullan
git branch -M main
git remote add origin https://github.com/<kullanici-adi>/<repo-adi>.git
git push -u origin main
```

## GitHub Pages ile yayınlama (opsiyonel)
1. `vite.config.ts` içinde `base` değerini `/<repo-adi>/` olarak değiştirin.
2. Repo ayarlarından **Pages → Source: GitHub Actions** seçin.
3. Bu repo, `.github/workflows/deploy.yml` dosyasıyla otomatik yayınlar.

Netlify/Vercel kullanıyorsanız:
- Build komutu: `npm run build`
- Publish directory: `dist`

---

**Not:** UI kit dosyaları `src/components/ui/*` içinde minimal olarak tanımlandı; Shadcn API'sine benzer davranır.
