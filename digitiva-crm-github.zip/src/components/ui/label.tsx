import React from 'react'
export const Label = ({ className='', ...props }: any) => <label className={`text-sm ${className}`} {...props} />
export default Label
