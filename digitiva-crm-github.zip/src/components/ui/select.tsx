import React from 'react'

export const SelectItem = ({ value, children }: any) => <option value={value}>{children}</option>
export const SelectTrigger = ({ children, className='' }: any) => <div className={className}>{children}</div>
export const SelectContent = ({ children }: any) => <>{children}</>
export const SelectValue = ({ placeholder }: any) => <span className="text-gray-500">{placeholder}</span>

export const Select = ({ value, onValueChange, children }: any) => {
  // Flatten down all SelectItem children from nested structure
  const flatten = (nodes: any): any[] => {
    const arr = React.Children.toArray(nodes) as any[]
    let items: any[] = []
    arr.forEach((node:any)=>{
      if (!React.isValidElement(node)) return
      // If it's SelectItem, push it
      // @ts-ignore
      if (node.type && node.type.name === 'SelectItem') {
        items.push(node)
      } else if (node.props && node.props.children) {
        items = items.concat(flatten(node.props.children))
      }
    })
    return items
  }
  const items = flatten(children)
  return (
    <select className="border rounded-md px-3 py-2 w-full" value={value} onChange={(e)=>onValueChange?.(e.target.value)}>
      <option value="" disabled>{/* placeholder */}</option>
      {items}
    </select>
  )
}

export default Select
