import React from 'react'
export const Button = ({ children, className='', variant='default', size='md', ...props }: any) => {
  const variants: any = {
    default: 'bg-black text-white hover:opacity-90',
    outline: 'border border-gray-300 bg-white hover:bg-gray-50',
    ghost: 'bg-transparent hover:bg-gray-100'
  }
  const sizes: any = { sm: 'px-2 py-1 text-sm', md: 'px-3 py-2', lg: 'px-4 py-2' }
  return <button className={`rounded-md ${variants[variant]||variants.default} ${sizes[size]||sizes.md} ${className}`} {...props}>{children}</button>
}
export default Button
