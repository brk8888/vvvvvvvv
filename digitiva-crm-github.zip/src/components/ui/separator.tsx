import React from 'react'
export const Separator = ({ className='', orientation='horizontal', ...props }: any) => (
  <div className={`${orientation==='vertical'?'w-px h-6':'h-px w-full'} bg-gray-200 ${className}`} {...props} />
)
export default Separator
