import React from 'react'
export const Badge = ({ children, className='', variant='default' }: any) => {
  const variants: any = {
    default: 'bg-black text-white',
    secondary: 'bg-gray-200 text-gray-800',
    outline: 'border border-gray-300 text-gray-700',
    destructive: 'bg-red-600 text-white'
  }
  return <span className={`inline-flex items-center px-2 py-0.5 text-xs rounded ${variants[variant]||variants.default} ${className}`}>{children}</span>
}
export default Badge
