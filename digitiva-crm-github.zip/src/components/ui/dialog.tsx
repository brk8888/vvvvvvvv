import React from 'react'
export const Dialog = ({ open, onOpenChange, children }: any) => open ? <>{children}</> : null
export const DialogContent = ({ className='', ...props }: any) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center">
    <div className="absolute inset-0 bg-black/40" onClick={()=>props.onClose?.()}></div>
    <div className={`relative bg-white rounded-2xl shadow-xl w-[min(720px,90vw)] ${className}`} {...props} />
  </div>
)
export const DialogHeader = ({ className='', ...props }: any) => <div className={`p-4 border-b ${className}`} {...props} />
export const DialogFooter = ({ className='', ...props }: any) => <div className={`p-4 border-t flex items-center justify-end gap-2 ${className}`} {...props} />
export const DialogTitle = ({ className='', ...props }: any) => <div className={`font-semibold ${className}`} {...props} />
export const DialogDescription = ({ className='', ...props }: any) => <div className={`text-sm text-gray-600 ${className}`} {...props} />
