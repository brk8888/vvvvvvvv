import React from 'react'
export const Checkbox = ({ checked=false, onCheckedChange, className='', ...props }: any) => {
  return <input type="checkbox" className={`h-4 w-4 ${className}`} checked={!!checked} onChange={e=>onCheckedChange?.(e.target.checked)} {...props} />
}
export default Checkbox
