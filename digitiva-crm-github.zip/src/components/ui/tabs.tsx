import React, { createContext, useContext } from 'react'
type Ctx = { value: string, onValueChange: (v:string)=>void }
const TabsCtx = createContext<Ctx>({ value:'', onValueChange: ()=>{} })
export const Tabs = ({ value, onValueChange, children }: any) => <TabsCtx.Provider value={{value, onValueChange}}>{children}</TabsCtx.Provider>
export const TabsList = ({ className='', ...props }: any) => <div className={`inline-flex gap-1 bg-gray-100 p-1 rounded-md ${className}`} {...props} />
export const TabsTrigger = ({ value, children }: any) => {
  const { value:val, onValueChange } = useContext(TabsCtx)
  const active = val===value
  return <button className={`px-3 py-1 rounded ${active?'bg-white border':'hover:bg-white/70'}`} onClick={()=>onValueChange(value)}>{children}</button>
}
export const TabsContent = ({ value, children }: any) => {
  const { value:val } = useContext(TabsCtx)
  return val===value ? <div>{children}</div> : null
}
