
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Phone, Upload, Download, Clock, Plus, FileSpreadsheet, Search, History, AlertTriangle,
  Home, BarChart3, Handshake, CalendarClock, ShoppingCart, Layers, Settings, KeyRound, Wallet,
  CreditCard, HelpCircle, MessageSquare, FileText, Video, PackagePlus, Package, Palette, Users
} from "lucide-react";
import * as XLSX from "xlsx";

const STAGES = [
  "Atandı",
  "İletişim Kurulamadı",
  "Görüşmede",
  "Olumlu",
  "Olumsuz",
  "İptal",
  "Satış Gerçekleşti",
] as const;
type Stage = typeof STAGES[number];

type Action = {
  id: string;
  note: string;
  stage: Stage;
  dueDate: string;
  dueTime: string;
  createdAt: string;
  done: boolean;
}
type Customer = {
  id: string;
  firmaAdi: string;
  isimSoyisim: string;
  email: string;
  telefon: string;
  ownerId?: string;
  actions: Action[];
}
type User = { id: string; name: string; email?: string; phone?: string; isOwner?: boolean; perms?: any; }

const LS_KEY = "digitiva-crm-v2";
const LS_SALES = "digitiva-crm-sales-v1";
const LS_USERS = "digitiva-crm-users-v1";
const LS_ACTIVE_USER = "digitiva-crm-active-user";

const tzAwareToday = () => { const now = new Date(); return new Date(now.getFullYear(), now.getMonth(), now.getDate()); };
const fmtDate = (d: string) => new Date(d).toLocaleDateString();
const fmtTime = (t: string) => t;
const toDateOnly = (iso: string) => { const d = new Date(iso); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const dateStrToday = () => { const t = tzAwareToday(); const mm = `${t.getMonth()+1}`.padStart(2,'0'); const dd = `${t.getDate()}`.padStart(2,'0'); return `${t.getFullYear()}-${mm}-${dd}`; };
const uuid = () => (crypto?.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2));

const normalize = (s = "") => s.toString().trim().toLowerCase()
  .replaceAll("ı","i").replaceAll("İ","i")
  .replace(/[çÇ]/g,"c").replace(/[ğĞ]/g,"g").replace(/[öÖ]/g,"o").replace(/[şŞ]/g,"s").replace(/[üÜ]/g,"u")
  .replace(/\\s+|\\./g,"");

const HEADER_CANDIDATES: any = {
  firmaAdi: ["firmaadi","firmaadı","firma","sirketadi","sirket"],
  isimSoyisim: ["isimsoyisim","isimsoysisim","adsoyad","adisoyadi","musteriadi"],
  email: ["emailadresi","email","eposta","e-posta"],
  telefon: ["telefon","telefonnumarasi","gsm","cep","phone"],
};

function useLocalStorageState<T>(key: string, initialValue: T){
  const [state, setState] = useState<T>(()=>{
    try{ const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : initialValue; } catch { return initialValue; }
  });
  useEffect(()=>{ try { localStorage.setItem(key, JSON.stringify(state)); } catch {} },[key,state]);
  return [state, setState] as const;
}

const nextPendingAction = (c: Customer) => {
  const pendings = c.actions.filter(a=> !a.done && a.dueDate);
  if (pendings.length===0) return undefined;
  return pendings.sort((a,b)=> new Date(`${a.dueDate}T${a.dueTime||'00:00'}`).getTime() - new Date(`${b.dueDate}T${b.dueTime||'00:00'}`).getTime())[0];
};
const classifyDue = (a?: Action) => {
  if (!a) return "none" as const;
  const today = tzAwareToday();
  const d = toDateOnly(`${a.dueDate}T00:00:00`);
  if (d.getTime() === today.getTime()) return "today" as const;
  if (d < today) return "overdue" as const;
  return "upcoming" as const;
};
const stageBadgeVariant = (s: Stage) => {
  switch(s){
    case "Atandı": return "secondary";
    case "İletişim Kurulamadı": return "destructive";
    case "Görüşmede": return "outline";
    case "Olumlu": return "default";
    case "Olumsuz": return "destructive";
    case "İptal": return "secondary";
    default: return "secondary";
  }
};

const MENU = [
  { group: "Ana Sayfa", items: [ { id: "dashboard", label: "Ana Sayfa", icon: Home } ] },
  { group: "Performans Detayları", items: [ { id: "performance", label: "Performans Detayları", icon: BarChart3 } ] },
  { group: "Fırsatlar", items: [
    { id: "opp_new", label: "Yeni Fırsat Ekle", icon: Plus },
    { id: "opp_all", label: "Tüm Fırsatlar", icon: Handshake },
    { id: "opp_today", label: "Bugün Aranacak Fırsatlar", icon: Clock },
    { id: "opp_overdue", label: "Arama Tarihi Geçen Fırsatlar", icon: AlertTriangle },
    { id: "opp_rules", label: "Fırsat Kuralları", icon: FileText },
  ]},
  { group: "Toplantılar", items: [ { id: "meetings", label: "Toplantılar", icon: CalendarClock } ] },
  { group: "Satışlar", items: [
    { id: "sales_all", label: "Tüm Satışlar", icon: ShoppingCart },
  ]},
  { group: "Kullanıcı Yönetimi", items: [ { id: "user_create", label: "Kullanıcı Oluştur", icon: Users }, { id: "users", label: "Kullanıcılar", icon: Users } ] },
];

export default function App(){
  const [customers, setCustomers] = useLocalStorageState<Customer[]>(LS_KEY, []);
  const [sales, setSales] = useLocalStorageState<{id:string,customerId:string,amount:number,date:string,createdAt:string}[]>(LS_SALES, []);
  const [users, setUsers] = useLocalStorageState<User[]>(LS_USERS, []);
  const [activeUserId, setActiveUserId] = useLocalStorageState<string>(LS_ACTIVE_USER, "");
  const activeUser = useMemo(()=> users.find(u=>u.id===activeUserId) || users[0], [users, activeUserId]);

  useEffect(()=>{
    if (users.length===0){
      const seed: User[] = [
        { id: uuid(), name: "Burak Atak", email: "burakatak@gmail.com", phone: "5424391989", isOwner: true },
        { id: uuid(), name: "İhsan Berk Aydın", email: "baydin@agevadigital.com", phone: "5373332019", isOwner: false },
        { id: uuid(), name: "Berkay Tiryaki", email: "btiryaki@agevadigital.com", phone: "5331365344", isOwner: false },
      ];
      setUsers(seed);
      setActiveUserId(seed[0].id);
    } else if (!activeUserId){
      setActiveUserId(users[0]?.id || "");
    }
  }, []);

  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("today");
  const [view, setView] = useState("dashboard");
  const fileInputRef = useRef<HTMLInputElement|null>(null);

  const [saleOpen, setSaleOpen] = useState(false);
  const [saleCustomer, setSaleCustomer] = useState<Customer|null>(null);
  const [saleForm, setSaleForm] = useState({ amount: "", date: new Date().toISOString().slice(0,10) });

  const [mappingOpen, setMappingOpen] = useState(false);
  const [headers, setHeaders] = useState<any[]>([]);
  const [rows, setRows] = useState<any[][]>([]);
  const [mapping, setMapping] = useState({ firmaAdi: "", isimSoyisim: "", email: "", telefon: "" });

  const filtered = useMemo(()=>{
    const q = normalize(query);
    const all = customers.filter((c)=>{
      const inText = normalize(`${c.firmaAdi} ${c.isimSoyisim} ${c.email} ${c.telefon}`).includes(q);
      if (!inText) return false;
      const next = nextPendingAction(c);
      const bucket = classifyDue(next);
      if (view === "opp_all") return true;
      if (view === "opp_today") return bucket === "today";
      if (view === "opp_overdue") return bucket === "overdue";
      if (view === "dashboard"){
        if (tab === "all") return true;
        if (tab === "today") return bucket === "today";
        if (tab === "overdue") return bucket === "overdue";
        if (tab === "upcoming") return bucket === "upcoming";
      }
      return true;
    });
    return all.sort((a,b)=>{
      const na = nextPendingAction(a); const nb = nextPendingAction(b);
      const ba = classifyDue(na); const bb = classifyDue(nb);
      const order: any = { overdue:0, today:1, upcoming:2, none:3 };
      if (order[ba] !== order[bb]) return order[ba]-order[bb];
      const da = na ? new Date(`${na.dueDate}T${na.dueTime||'00:00'}`).getTime() : Infinity;
      const db = nb ? new Date(`${nb.dueDate}T${nb.dueTime||'00:00'}`).getTime() : Infinity;
      return da-db;
    });
  }, [customers, query, tab, view]);

  const stats = useMemo(()=>{
    let overdue=0,today=0,upcoming=0,none=0;
    for (const c of customers){
      const n = nextPendingAction(c);
      const b = classifyDue(n as any);
      if (b==='overdue') overdue++; else if (b==='today') today++; else if (b==='upcoming') upcoming++; else none++;
    }
    return { overdue, today, upcoming, none, total: customers.length };
  }, [customers]);

  const onPickFile = () => fileInputRef.current?.click();
  const autoMapHeaders = (hdrs: any[])=>{
    const map: any = { firmaAdi:'', isimSoyisim:'', email:'', telefon:'' };
    for (const h of hdrs){
      const n = normalize(String(h));
      for (const key of Object.keys(HEADER_CANDIDATES)){
        // @ts-ignore
        if (HEADER_CANDIDATES[key].some((cand: string)=> n.includes(cand))){ if (!map[key]) map[key] = h; }
      }
    }
    return map;
  };
  const readSpreadsheet = async(file: File)=>{
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, { type:'array' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const arr: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (!arr || arr.length===0) return;
    const hdrs = arr[0];
    const body = arr.slice(1).filter(r=> r.some(x=> (x??'').toString().trim()!==''));
    const auto = autoMapHeaders(hdrs as any[]);
    const allMapped = Object.values(auto).every(v=> !!v);
    setHeaders(hdrs as any[]);
    setRows(body);
    if (allMapped){ applyImport(hdrs as any[], body, auto); }
    else { setMapping(auto); setMappingOpen(true); }
  };
  const applyImport = (hdrs: any[], bodyRows: any[][], headerMap: any)=>{
    const idx = (name: string)=> hdrs.indexOf(headerMap[name]);
    const newCustomers: Customer[] = [];
    for (const r of bodyRows){
      const firmaAdi = (r[idx('firmaAdi')] ?? '').toString().trim();
      const isimSoyisim = (r[idx('isimSoyisim')] ?? '').toString().trim();
      const email = (r[idx('email')] ?? '').toString().trim();
      const telefon = (r[idx('telefon')] ?? '').toString().trim();
      if (!(firmaAdi||isimSoyisim||email||telefon)) continue;
      const c: Customer = { id: uuid(), firmaAdi, isimSoyisim, email, telefon, ownerId: (activeUser?.id || undefined), actions: [ { id: uuid(), note: 'Başlangıç kaydı', stage: 'Atandı', dueDate: '', dueTime: '', createdAt: new Date().toISOString(), done: true } ] };
      newCustomers.push(c);
    }
    if (newCustomers.length===0) return;
    setCustomers(prev=>{
      const key = (x: Customer)=> `${normalize(x.email)}|${normalize(x.telefon)}`;
      const map = new Map(prev.map(p=>[key(p), p]));
      for (const nc of newCustomers){ if (!map.has(key(nc))) map.set(key(nc), nc); }
      return Array.from(map.values());
    });
    setMappingOpen(false);
  };
  const exportTemplate = (type: 'xlsx'|'csv' = "xlsx")=>{
    const data = [[ "Firma Adı","İsim Soyİsim","Email Adresi","Telefon" ], ["Digitiva","Ad Soyad","ad@ornek.com","+90 555 444 33 22"]];
    const ws = XLSX.utils.aoa_to_sheet(data); const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Müşteriler");
    const fname = `digitiva-crm-sablon.${type==='csv'?'csv':'xlsx'}`;
    if (type==='csv'){ const csv = XLSX.utils.sheet_to_csv(ws); const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = fname; a.click(); URL.revokeObjectURL(url); }
    else { XLSX.writeFile(wb, fname); }
  };
  const exportAll = ()=>{
    const headers = ["Firma Adı","İsim Soyİsim","Email Adresi","Telefon","Son Aşama","Son Aksiyon Tarihi","Son Aksiyon Saati","Aksiyon Notu"];
    const rows = customers.map(c=>{ const n = nextPendingAction(c) || c.actions[c.actions.length-1]; return [c.firmaAdi,c.isimSoyisim,c.email,c.telefon, n?.stage||'', n?.dueDate||'', n?.dueTime||'', n?.note||'']; });
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]); const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "CRM"); XLSX.writeFile(wb, `digitiva-crm-aktarim-${new Date().toISOString().slice(0,10)}.xlsx`);
  };

  const [newOpp, setNewOpp] = useState({ firmaAdi:'', isimSoyisim:'', email:'', telefon:'', note:'', stage:'', date: dateStrToday(), time: '09:30' });
  const saveNewOpp = ()=>{
    if (!newOpp.firmaAdi && !newOpp.isimSoyisim) return;
    if (!newOpp.stage || !newOpp.date || !newOpp.time) return;
    const c: Customer = { id: uuid(), firmaAdi: newOpp.firmaAdi.trim(), isimSoyisim: newOpp.isimSoyisim.trim(), email: newOpp.email.trim(), telefon: newOpp.telefon.trim(), ownerId: (activeUser?.id || undefined), actions: [ { id: uuid(), note: newOpp.note.trim() || 'Aksiyon', stage: newOpp.stage as Stage, dueDate: newOpp.date, dueTime: newOpp.time, createdAt: new Date().toISOString(), done: false } ] };
    setCustomers(prev=> [c, ...prev]);
    setNewOpp({ firmaAdi:'', isimSoyisim:'', email:'', telefon:'', note:'', stage:'', date: dateStrToday(), time: '09:30' });
    setView('opp_all');
  };

  const handleMenuClick = (id: string)=>{
    setView(id);
    if (id==='opp_today') setTab('today');
    if (id==='opp_overdue') setTab('overdue');
    if (id==='opp_all') setTab('all');
  };

  const openSale = (c: Customer)=>{ setSaleCustomer(c); setSaleForm({ amount:'', date: new Date().toISOString().slice(0,10) }); setSaleOpen(true); };
  const saveSale = ()=>{
    if (!saleCustomer || !saleForm.amount) return;
    const order = { id: uuid(), customerId: saleCustomer.id, amount: Number(saleForm.amount), date: saleForm.date, createdAt: new Date().toISOString() };
    setSales(prev=> [order, ...prev]);
    setCustomers(prev=> prev.map(c=> c.id===saleCustomer.id ? ({ ...c, actions: [...c.actions, { id: uuid(), note: `Satış: ${order.amount}₺`, stage: 'Satış Gerçekleşti', dueDate: order.date, dueTime: '', createdAt: new Date().toISOString(), done: true }] }) : c));
    setSaleOpen(false);
    setView('sales_all');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="hidden md:flex w-72 bg-white border-r sticky top-0 h-screen">
        <ScrollArea className="w-full">
          <div className="p-3">
            <div className="flex items-center gap-2 mb-3">
              <FileSpreadsheet className="w-6 h-6" />
              <div>
                <div className="font-semibold">Digitiva CRM – Mini</div>
                <div className="text-xs text-muted-foreground">Excel → Fırsat & Aksiyon</div>
              </div>
            </div>
            {MENU.map((sec, gi) => (
              <div key={gi} className="mb-3">
                <div className="text-[11px] uppercase tracking-wide text-muted-foreground px-2 mb-1">{sec.group}</div>
                <div className="space-y-1">
                  {sec.items.map((it) => (
                    <button key={it.id} onClick={() => handleMenuClick(it.id)} className={`w-full text-left px-2 py-2 rounded-md text-sm inline-flex items-center gap-2 hover:bg-gray-100 ${view===it.id? 'bg-gray-100 font-medium':''}`}>
                      {it.icon ? <it.icon className="w-4 h-4"/> : null}
                      <span>{it.label}</span>
                    </button>
                  ))}
                </div>
                {gi < MENU.length-1 && <Separator className="my-3"/>}
              </div>
            ))}
          </div>
        </ScrollArea>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b">
          <div className="max-w-6xl mx-auto flex items-center gap-3 p-3">
            <div className="md:hidden font-semibold">Digitiva CRM – Mini</div>
            <div className="ml-auto flex items-center gap-2">
              <Select value={activeUser?.id || ""} onValueChange={(v)=>setActiveUserId(v)}>
                <SelectTrigger className="w-56"><SelectValue placeholder="Aktif Kullanıcı"/></SelectTrigger>
                <SelectContent>
                  {users.map(u => <SelectItem key={u.id} value={u.id}>{u.name}{u.isOwner? " (Sahip)":""}</SelectItem>)}
                </SelectContent>
              </Select>
              {activeUser?.isOwner && (
                <>
                  <Button variant="outline" onClick={() => exportTemplate("xlsx")} title="Şablon indir"><Download className="w-4 h-4 mr-2"/>Şablon</Button>
                  <Button variant="outline" onClick={exportAll} title="Dışa aktar"><Download className="w-4 h-4 mr-2"/>Export</Button>
                  <Button onClick={() => fileInputRef.current?.click()} title="Excel/CSV içe aktar"><Upload className="w-4 h-4 mr-2"/>İçe Aktar</Button>
                </>
              )}
              <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) readSpreadsheet(f); if (fileInputRef.current) fileInputRef.current.value = ''; }} />
            </div>
          </div>
        </header>

        <main className="max-w-6xl mx-auto p-4">
          {view === "dashboard" && (
            <Dashboard stats={stats} query={query} setQuery={setQuery} tab={tab} setTab={setTab} filtered={filtered} onPickFile={() => fileInputRef.current?.click()} onOpenSale={openSale} />
          )}

          {view.startsWith("opp_") && view !== "opp_new" && (
            <OpportunitiesView view={view} query={query} setQuery={setQuery} filtered={filtered} onPickFile={() => fileInputRef.current?.click()} onOpenSale={openSale} />
          )}

          {view === "opp_new" && (
            <NewOpportunityForm newOpp={newOpp} setNewOpp={setNewOpp} saveNewOpp={saveNewOpp} />
          )}

          {view === "sales_all" && (
            <SalesView customers={customers} sales={sales} />
          )}
        </main>

        {/* Satış Ekle Dialog */}
        <Dialog open={saleOpen} onOpenChange={setSaleOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Satış Kaydı</DialogTitle>
              <DialogDescription>{saleCustomer ? `${saleCustomer.firmaAdi} · ${saleCustomer.isimSoyisim}` : ""}</DialogDescription>
            </DialogHeader>
            <div className="grid md:grid-cols-2 gap-3 p-4">
              <div>
                <Label>Tutar (₺)</Label>
                <Input type="number" value={saleForm.amount} onChange={(e)=>setSaleForm((s)=>({ ...s, amount: e.target.value }))} placeholder="Örn: 70000"/>
              </div>
              <div>
                <Label>Tarih</Label>
                <Input type="date" value={saleForm.date} onChange={(e)=>setSaleForm((s)=>({ ...s, date: e.target.value }))}/>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={()=>setSaleOpen(false)}>İptal</Button>
              <Button onClick={saveSale} disabled={!saleForm.amount}>Kaydet</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <footer className="max-w-6xl mx-auto p-6 text-xs text-muted-foreground">
          Digitiva · Mini CRM — Excel içe aktarma, fırsat kartları, aksiyon planlama ve satış ekleme. Veriler tarayıcınızda saklanır.
        </footer>
      </div>
    </div>
  )
}

function Dashboard({ stats, query, setQuery, tab, setTab, filtered, onPickFile, onOpenSale }: any){
  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
        <Card><CardHeader className="p-3"><CardTitle className="text-sm">Toplam</CardTitle></CardHeader><CardContent className="p-3 text-2xl font-bold">{stats.total}</CardContent></Card>
        <Card><CardHeader className="p-3"><CardTitle className="text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4"/>Geciken</CardTitle></CardHeader><CardContent className={stats.overdue>0? 'p-3 text-2xl font-bold text-red-600':'p-3 text-2xl font-bold'}>{stats.overdue}</CardContent></Card>
        <Card><CardHeader className="p-3"><CardTitle className="text-sm flex items-center gap-2"><Clock className="w-4 h-4"/>Bugün</CardTitle></CardHeader><CardContent className="p-3 text-2xl font-bold">{stats.today}</CardContent></Card>
        <Card><CardHeader className="p-3"><CardTitle className="text-sm">Yaklaşan</CardTitle></CardHeader><CardContent className="p-3 text-2xl font-bold">{stats.upcoming}</CardContent></Card>
        <Card className="hidden md:block"><CardHeader className="p-3"><CardTitle className="text-sm">Aksiyonu Yok</CardTitle></CardHeader><CardContent className="p-3 text-2xl font-bold">{stats.none}</CardContent></Card>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <div className="relative flex-1">
          <Input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Ara: firma, kişi, email, telefon" className="pl-9" />
          <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2"/>
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="today">Bugün</TabsTrigger>
            <TabsTrigger value="overdue">Geciken</TabsTrigger>
            <TabsTrigger value="upcoming">Yaklaşan</TabsTrigger>
            <TabsTrigger value="all">Tümü</TabsTrigger>
          </TabsList>
        </Tabs>
        <Button variant="outline" onClick={onPickFile}><Upload className="w-4 h-4 mr-2"/>İçe Aktar</Button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState onPickFile={onPickFile} />
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map((c: Customer) => (
            <CustomerCard key={c.id} c={c} onOpenSale={onOpenSale} />
          ))}
        </div>
      )}
    </>
  )
}

function OpportunitiesView({ view, query, setQuery, filtered, onPickFile, onOpenSale }: any){
  const heading = view === "opp_all" ? "Tüm Fırsatlar" : view === "opp_today" ? "Bugün Aranacak Fırsatlar" : "Arama Tarihi Geçen Fırsatlar";
  return (
    <>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">{heading}</h2>
        <div className="relative w-80 max-w-full">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Ara: firma, kişi, email, telefon" className="pl-9" />
          <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2"/>
        </div>
      </div>
      {filtered.length === 0 ? (
        <EmptyState onPickFile={onPickFile} />
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map((c: Customer) => (
            <CustomerCard key={c.id} c={c} onOpenSale={onOpenSale} />
          ))}
        </div>
      )}
    </>
  )
}

function SalesView({ customers, sales }: any){
  const nameOf = (cid: string)=> customers.find((c: Customer)=>c.id===cid)?.firmaAdi || '—';
  const rows = sales.slice().sort((a:any,b:any)=> new Date(b.date).getTime() - new Date(a.date).getTime());
  const total = rows.reduce((s:number,x:any)=> s+x.amount, 0);
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Tüm Satışlar</h2>
        <div className="text-sm text-muted-foreground">Toplam: <b>{Intl.NumberFormat('tr-TR').format(total)}</b> ₺</div>
      </div>
      <div className="overflow-auto border rounded-md bg-white">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-2 text-left">Tarih</th>
              <th className="p-2 text-left">Firma</th>
              <th className="p-2 text-left">Tutar</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((s:any)=> (
              <tr key={s.id} className="border-t">
                <td className="p-2">{fmtDate(s.date)}</td>
                <td className="p-2">{nameOf(s.customerId)}</td>
                <td className="p-2">{Intl.NumberFormat('tr-TR').format(s.amount)} ₺</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function EmptyState({ onPickFile }: any){
  return (
    <Card className="border-dashed">
      <CardHeader><CardTitle className="text-base">Henüz kayıt yok</CardTitle></CardHeader>
      <CardContent className="space-y-2 text-sm">
        <p>Excel/CSV ile müşteri listenizi içe aktarın. Başlıklar: <b>Firma Adı</b>, <b>İsim Soyİsim</b>, <b>Email Adresi</b>, <b>Telefon</b>.</p>
        <div className="flex gap-2"><Button onClick={onPickFile}><Upload className="w-4 h-4 mr-2"/>İçe Aktar</Button></div>
      </CardContent>
    </Card>
  )
}

function CustomerCard({ c, onOpenSale }: any){
  const next = nextPendingAction(c);
  const bucket = classifyDue(next as any);
  const last = c.actions[c.actions.length-1];
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base">{c.firmaAdi}</CardTitle>
            <div className="text-sm text-muted-foreground">{c.isimSoyisim} · {c.email}</div>
            <div className="text-sm flex items-center gap-1 mt-1">
              <a href={`tel:${c.telefon}`} className="inline-flex items-center gap-1 underline"><Phone className="w-3 h-3"/> {c.telefon}</a>
              {last?.stage && <Badge variant={stageBadgeVariant(last.stage)} className="ml-2">{last.stage}</Badge>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <BucketBadge bucket={bucket} />
            <Button variant="outline" size="sm" onClick={()=> onOpenSale?.(c)} title="Satışı kaydet ve aşamayı güncelle">Satış Ekle</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-xs text-muted-foreground">
          {next ? (
            <div className="flex items-center gap-2"><Clock className="w-3 h-3"/> Sonraki arama: <b>{fmtDate(`${next.dueDate}T00:00:00`)}</b> {next.dueTime && <>· {fmtTime(next.dueTime)}</>} — {next.note}</div>
          ) : (
            <div>Planlı aksiyon yok.</div>
          )}
        </div>
        <div className="space-y-1">
          <div className="text-xs font-medium flex items-center gap-1"><History className="w-3 h-3"/> Görüşme Geçmişi</div>
          <div className="max-h-40 overflow-auto pr-1 space-y-1">
            {c.actions.slice().reverse().map((a: Action) => (
              <div key={a.id} className="text-xs bg-muted rounded p-2 flex items-center justify-between gap-2">
                <div>
                  <div className="font-medium">{a.stage}</div>
                  <div className="text-muted-foreground">{a.note}</div>
                  {a.dueDate && (<div className="text-[11px] mt-1">Tarih: {a.dueDate} {a.dueTime}</div>)}
                </div>
                {!a.done && (<Button size="sm" variant="outline" disabled>Tamamlandı</Button>)}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function BucketBadge({ bucket }: any){
  if (bucket==='overdue') return <Badge variant="destructive">Geciken</Badge>;
  if (bucket==='today') return <Badge>Bugün</Badge>;
  if (bucket==='upcoming') return <Badge variant="secondary">Yaklaşan</Badge>;
  return <Badge variant="outline">Plan Yok</Badge>;
}
