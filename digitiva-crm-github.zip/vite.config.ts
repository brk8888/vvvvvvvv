import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// If you'll deploy to GitHub Pages under a repository like user/repo,
// set base to '/repo/' (or keep '/' for root).
export default defineConfig({
  plugins: [react()],
  base: '/', // <-- change to '/<repo>/' if using GitHub Pages
  resolve: { alias: { '@': '/src' } }
})
